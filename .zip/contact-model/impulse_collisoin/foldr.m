function result = foldr(f, xs, x0)
	
end
