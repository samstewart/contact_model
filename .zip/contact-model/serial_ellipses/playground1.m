ellipse_distance_to_point([1 2], 10)


[t1, t2, d] = edge_points_dist_between_ellipses([1 0], [1 9.99], 0, pi, pi/60, 10)

random_project1([1 0], [1 9.99], [30i + 30], 0, pi)

