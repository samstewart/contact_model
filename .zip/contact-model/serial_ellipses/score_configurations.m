function scores =  
