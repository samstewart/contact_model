# Today
Submit resume to Jane Street, Google, Microsoft. Add unix experience. Upload Julia crowd project to github. (30min) [done]

Thesis:
Get 2 guys working (1h)

Industry Prep:
Continue conjugate gradient post. Grahm-Schmidt in case of different notion of orthogonality (30min) [done]
Try, in matlab, to solve poissons equation in $[0, 1]$ via finite elements (30min) [done]

Admin:
send estimated tax / dates / expense to Nick (15min) [done]
get packages to UPS store for return (1h) [done]
get package from office?
buy some bonds with Vanguard account (30min) [done]

# Yesterday
Update resume (1h)
Submit to
Jane Street
Google
Microsoft
Flatiron [done]

Thesis:
Get distance function working and start on projection for two guys (30m) [done]

Industry Prep:
Start writing post on conjugate gradient (30m) [done]
Implement support vector machines in python directly via optimization. Then test against built in functions (1h)

Admin:
assemble tax info and meet with tax consultant

Week
Apply to recurse center
Python tic/tac/toe
Read ellipse paper from 90s on contact dynamics for contact method. Faster than ours?
See if I can get standard DEM software to do ellipse simulation.
Read theses of other students who went into industry (Jeff, Vahan, Tyler, Nick) to see expectations
Get fast collision detection working

Month
2 high quality blog posts


Spring Semester
Find something to do for the summer
2 high quality blog posts
Clarify thesis expectations with Vladimir
Fast algorithm for simulating ellipses

Summer

Fall Semester

Year
