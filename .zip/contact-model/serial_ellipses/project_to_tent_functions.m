function coeffs = project_to_tent_functions(f, a, b, n)
% Divide the domain [a, b] into n intervals

end
