function v = replace_row(v, k, w)
v(k, :) = w;
end
