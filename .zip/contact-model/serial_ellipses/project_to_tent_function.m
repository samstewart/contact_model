function alpha = project_to_tent_function(f, k, x1, x2, x3)
alpha = integral(f * (x - x1) / (
end
