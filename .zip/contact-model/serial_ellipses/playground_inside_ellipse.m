ellipses_overlap([1 0], [1 9.99])
quad_score_perturb1([1 0], [1 10], [1 -.1; 1 0; 1 .1], 20 + 1i)

random_project([1 0], [1 9.99], 20, 0, 0)

