function [n1, n2, p1, p2, d] = maury_algorithm(c1, c2)

end
