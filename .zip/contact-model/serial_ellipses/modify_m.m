function M = modify_m(M)
M(1,2) = Inf;
end
