The idea is quite simple, project in some function space to a simpler finite dimensional space. 

Once in this finite dimensional space, solving a PDE simply becomes inverting a matrix.

The right space for the approximation is determined by the weak form of the PDE.


