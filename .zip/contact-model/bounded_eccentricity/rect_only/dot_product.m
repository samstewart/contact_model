function dots = dot_product(z1, z2)
dots = zeros(length
end
