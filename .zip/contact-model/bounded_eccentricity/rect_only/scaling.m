function M = scaling(scale)
M = [scale 0; 0 1];
end
