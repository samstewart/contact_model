function deviation = deviation_from_velocity(config)
deviation = .2 * abs(angle(config(1,1) / i)); % now just deviation from sideways
end
