function t = map(f, v)
for i =1: 
end
