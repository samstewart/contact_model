function draw_rectangle(config, w, h)
	ps = [
end
