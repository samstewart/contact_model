function shuffled = shuffle(v)
shuffled = v(randperm(length(v)));
end
