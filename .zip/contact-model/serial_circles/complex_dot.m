function d = complex_dot(z1, z2)
d = real(z1 * conj(z2));
end

