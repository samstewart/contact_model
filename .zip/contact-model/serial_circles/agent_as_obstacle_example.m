function agent_as_obstacle_example()

end
