function m = not_in(elem, v)
m = all(elem ~= v);
end
