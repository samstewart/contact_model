function c = l1_norm(v)
c = sum(abs(v));
end
