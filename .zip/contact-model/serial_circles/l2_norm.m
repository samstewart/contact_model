function c = l2_norm(v)
c = sqrt(sum(abs(v).^2));
end
