What is the right direction to move for my project?

What are my goals?
To tell a good story
To combine numerics and math
To do something new
To do something creative
To learn stuff relevant to solving real-world problems
To produce something concise
To avoid bullshit (I've been trying to avoid this from the beginning)

Overall, I'm tired of how sanitized the problems are, in math. But at the same time, engineering is tedious.

Fundamentally, I have no physical observations I am trying to explain with my model, nor data even I did have these. 

I don't like how artificial the math problems are. But at the same time, properly framing the problem can be powerful because it refines the question.  

I don't like how isolated I am. The technical details are fun, but not really engaging over the long term. I'm interested, just not very excited by them.

To get the mathematics PhD, I can prove an entirely theoretical result about the existence 

We could look at how the force chains differ for ellipses?

Can we obtain the circle method as a limit of the DEM technique? Can I obtain the discrete contact method model from some carefully chosen repulsive force?
