function inelastic_collision_example()
fun_simulation([0; 3], @(q) [0; -.2], 1/2)
end
